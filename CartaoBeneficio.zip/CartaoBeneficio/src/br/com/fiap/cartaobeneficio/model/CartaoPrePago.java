package br.com.fiap.cartaobeneficio.model;

import br.com.fiap.cartaobeneficio.exception.InsufficientBalanceException;
import br.com.fiap.cartaobeneficio.exception.OverflowBalanceException;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class CartaoPrePago {

    private static double valorMaximo = 10_000;

    private long id;
    private String numero;
    private String nome;
    private int codigo;
    private LocalDate validade;
    private double saldo;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public LocalDate getValidade() {
        return validade;
    }

    public void setValidade(LocalDate validade) {
        this.validade = validade;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public void pagamento(double valor, String beneficiado, LocalDateTime horario)
        throws InsufficientBalanceException {
        if (valor > saldo)
            throw new InsufficientBalanceException("Saldo insuficiente");
        saldo = saldo - valor;
    }

    public void deposito(double valor, LocalDateTime horario)
        throws OverflowBalanceException {
        if (saldo + valor > valorMaximo)
            throw new OverflowBalanceException("Limite máximo atingido!");
        saldo = saldo + valor;
    }

}
