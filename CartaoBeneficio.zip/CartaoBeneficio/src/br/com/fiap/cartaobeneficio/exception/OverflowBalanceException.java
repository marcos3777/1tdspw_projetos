package br.com.fiap.cartaobeneficio.exception;

public class OverflowBalanceException extends Exception {
    public OverflowBalanceException(String s) {
        super(s);
    }
}
