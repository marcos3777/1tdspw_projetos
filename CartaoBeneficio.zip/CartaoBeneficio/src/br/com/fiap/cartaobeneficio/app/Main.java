package br.com.fiap.cartaobeneficio.app;

import br.com.fiap.cartaobeneficio.exception.OverflowBalanceException;
import br.com.fiap.cartaobeneficio.model.CartaoPrePago;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class Main {

    public static void main(String[] args) {
        LocalDateTime ldt = LocalDateTime.of(2024, 8, 8, 23, 10);
        CartaoPrePago cartao = new CartaoPrePago();
        cartao.setCodigo(111);
        cartao.setNome("Fulano De Tal");
        cartao.setNumero("3243 3943 0920 8739");
        cartao.setValidade(LocalDate.of(2026, 10, 1));

        try {
            cartao.deposito(4000, ldt);
        } catch (OverflowBalanceException e) {
            throw new RuntimeException(e);
        }


    }
}
